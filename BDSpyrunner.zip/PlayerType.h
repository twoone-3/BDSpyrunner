#pragma once
#include "include/Python.h"
#include "include/structmember.h"

typedef struct {
	const char* Url;
} PlayerType_Body;

typedef struct {
	PyObject_HEAD
		PlayerType_Body* RequestBody;
} RequestType_Struct;

static void
RequestType_Deal_RequestBody(PyObject* obj) {
	RequestType_Struct* self = (RequestType_Struct*)obj;
	Py_TYPE(obj)->tp_free((PyObject*)self);
}

static PyObject*
RequestType_New(PyTypeObject* type, PyObject* args, PyObject* kwds) {
	RequestType_Struct* self;

	self = (RequestType_Struct*)type->tp_alloc(type, 0);
	self->RequestBody = new PlayerType_Body();
	self->RequestBody->Url = "None";
	return (PyObject*)self;
}

static int
RequestType_Init(RequestType_Struct* self, PyObject* args, PyObject* kwds) {

	return 0;
}
static auto* _cstc(const char* content) {
	char* c = nullptr;
	c = const_cast<char*>(content);
	return c;
}

static PyMemberDef RequestType_Members[] = {
	{_cstc("RequestBody"), T_INT, offsetof(RequestType_Struct, RequestBody), 0, _cstc("RequestBody")},
	{NULL}  /* Sentinel */
};

static PyObject*
RequestType_Method_GetUrl(RequestType_Struct* self, PyObject* args) {
	return PyUnicode_FromString(self->RequestBody->Url);
}
static PyMethodDef RequestType_Methods[] = {
	{"GetUrl", (PyCFunction)RequestType_Method_GetUrl, METH_VARARGS,
	 "Get requested url from Diean.",
	},
	{NULL}  /* Sentinel */
};

static PyTypeObject RequestType_Type = {
	PyObject_HEAD_INIT(NULL)
	"DieanRequest",             /*tp_name*/
	sizeof(RequestType_Struct), /*tp_basicsize*/
	0,                         /*tp_itemsize*/
	(destructor)RequestType_Deal_RequestBody,/*tp_dealloc*/
	0,                         /*tp_print*/
	0,                         /*tp_getattr*/
	0,                         /*tp_setattr*/
	0,                         /*tp_compare*/
	0,                         /*tp_repr*/
	0,                         /*tp_as_number*/
	0,                         /*tp_as_sequence*/
	0,                         /*tp_as_mapping*/
	0,                         /*tp_hash */
	0,                         /*tp_call*/
	0,                         /*tp_str*/
	0,                         /*tp_getattro*/
	0,                         /*tp_setattro*/
	0,                         /*tp_as_buffer*/
	Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE,/*tp_flags*/
	"Diean request type.",          /* tp_doc */
	0,                         /* tp_traverse */
	0,                         /* tp_clear */
	0,                         /* tp_richcompare */
	0,                         /* tp_weaklistoffset */
	0,                         /* tp_iter */
	0,                         /* tp_iternext */
	RequestType_Methods,      /* tp_methods */
	RequestType_Members,      /* tp_members */
	0,                         /* tp_getset */
	0,                         /* tp_base */
	0,                         /* tp_dict */
	0,                         /* tp_descr_get */
	0,                         /* tp_descr_set */
	0,                         /* tp_dictoffset */
	(initproc)RequestType_Init,/* tp_init */
	0,                         /* tp_alloc */
	RequestType_New,                 /* tp_new */
};
